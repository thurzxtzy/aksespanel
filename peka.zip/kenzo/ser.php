<?php 

$nik = "🔫Result Vvip Thurzx🔫";
$sender = "support@bossthurzx.ID";
?>